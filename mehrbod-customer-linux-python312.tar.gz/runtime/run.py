#!/usr/bin/env python3
import _run_entry  # compiled entrypoint
