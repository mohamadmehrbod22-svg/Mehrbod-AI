#!/usr/bin/env python3
import _manage_entry  # compiled CLI entrypoint
