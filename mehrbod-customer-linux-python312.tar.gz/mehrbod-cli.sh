#!/usr/bin/env bash
# Mehrbod server CLI
DIR=/opt/mehrbod
PY="$DIR/venv/bin/python"
CERT=/etc/mehrbod/cert

selfsign() {
  mkdir -p "$CERT"
  openssl req -x509 -nodes -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -days 3650 \
    -subj "/CN=mehrbod" -keyout "$CERT/key.pem" -out "$CERT/fullchain.pem" >/dev/null 2>&1
  chmod 600 "$CERT/key.pem"
  echo "گواهی خودامضا ساخته شد (مرورگر هشدار نشان می‌دهد؛ برای SSL معتبر: mehrbod ssl)."
}

issue_ssl() {
  local D="$1"
  [ -n "$D" ] || read -rp "دامنه: " D
  [ -n "$D" ] || { echo "دامنه لازم است"; return 1; }
  [ -x ~/.acme.sh/acme.sh ] || curl -s https://get.acme.sh | sh -s email="admin@$D" >/dev/null
  ~/.acme.sh/acme.sh --set-default-ca --server letsencrypt >/dev/null 2>&1
  # standalone mode needs port 80 free (no nginx involved)
  ~/.acme.sh/acme.sh --issue --standalone -d "$D" --keylength ec-256 --force || return 1
  mkdir -p "$CERT"
  ~/.acme.sh/acme.sh --install-cert -d "$D" --ecc \
    --fullchain-file "$CERT/fullchain.pem" --key-file "$CERT/key.pem" \
    --reloadcmd "systemctl restart mehrbod"
  chmod 600 "$CERT/key.pem"
  (cd "$DIR" && $PY manage.py setdomain "$D")
  echo "SSL برای $D فعال شد؛ تمدید خودکار توسط acme.sh انجام می‌شود."
}

case "$1" in
  status)   systemctl status mehrbod --no-pager -l ;;
  start|stop|restart) systemctl "$1" mehrbod ;;
  logs)     journalctl -u mehrbod -n 100 --no-pager ;;
  url)      (cd "$DIR" && $PY manage.py url) ;;
  passwd)
    read -rp "نام کاربری جدید (خالی = بدون تغییر): " U
    read -rsp "رمز جدید: " P; echo
    [ ${#P} -ge 8 ] || { echo "حداقل ۸ کاراکتر"; exit 1; }
    (cd "$DIR" && MB_USER="$U" MB_PASS="$P" $PY manage.py setpass) && systemctl restart mehrbod ;;
  license)  (cd "$DIR" && /usr/local/bin/mehrbod-license-client activate) && systemctl restart mehrbod ;;
  ssl)      issue_ssl "$2" && systemctl restart mehrbod ;;
  selfsign) selfsign ;;
  uninstall)
    read -rp "حذف کامل مهربد؟ (yes): " A; [ "$A" = "yes" ] || exit 0
    systemctl disable --now mehrbod 2>/dev/null
    rm -rf /etc/systemd/system/mehrbod.service "$DIR" /etc/mehrbod /usr/local/bin/mehrbod
    systemctl daemon-reload; echo "حذف شد." ;;
  *) echo "استفاده: mehrbod {status|start|stop|restart|logs|url|license|passwd|ssl [دامنه]|selfsign|uninstall}" ;;
esac
