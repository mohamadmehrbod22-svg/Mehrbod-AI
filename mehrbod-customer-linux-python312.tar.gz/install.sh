#!/usr/bin/env bash
# Mehrbod installer — run as root:  bash install.sh
set -e
[ "$(id -u)" -eq 0 ] || { echo "این اسکریپت را با root اجرا کنید."; exit 1; }

SRC="$(cd "$(dirname "$0")" && pwd)"
DIR=/opt/mehrbod

echo "== نصب پیش‌نیازهای اولیه =="
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null
apt-get install -y python3 python3-venv python3-pip python3-cryptography curl socat cron openssl openssh-client sshpass git >/dev/null

# ── لایسنس: قبل از هر کار دیگری ──
echo
echo "== بررسی لایسنس =="
mkdir -p /etc/mehrbod
export MEHRBOD_DIR=/etc/mehrbod
LIC_OK=0
for i in 1 2 3; do
  if "$SRC/mehrbod-license-client" activate; then LIC_OK=1; break; fi
done
if [ "$LIC_OK" != "1" ]; then
  echo "لایسنس معتبر وارد نشد؛ نصب متوقف شد."
  echo "برای عیب‌یابی: "$SRC/mehrbod-license-client" diag"
  exit 1
fi

UPDATE=0
if [ -f /etc/mehrbod/config.json ]; then
  read -rp "مهربد از قبل نصب است. فقط آپدیت شود و تنظیمات (رمز، کلید API، دامنه) بماند؟ [Y/n]: " A
  [ "${A,,}" = "n" ] || UPDATE=1
fi

echo "== کپی فایل‌ها =="
mkdir -p "$DIR" /etc/mehrbod/cert /var/log/mehrbod
cp -r "$SRC"/runtime/. "$DIR"/
cp "$SRC/mehrbod-cli.sh" /usr/local/bin/mehrbod
chmod +x /usr/local/bin/mehrbod
cp "$SRC/mehrbod-license-client" /usr/local/bin/mehrbod-license-client
chmod 755 /usr/local/bin/mehrbod-license-client
python3 -m venv "$DIR/venv"
"$DIR/venv/bin/pip" install -q --upgrade pip
"$DIR/venv/bin/pip" install -q fastapi "uvicorn[standard]" httpx psutil cryptography

if [ "$UPDATE" = "1" ]; then
  # config.json is untouched; only the model is switched to the new default
  (cd "$DIR" && "$DIR/venv/bin/python" "$DIR/manage.py" setmodel gemini-3.8-flash)
  systemctl daemon-reload; systemctl restart mehrbod; sleep 2
  echo "آپدیت شد. مدل: gemini-3.8-flash"
  echo "آدرس پنل: $("$DIR/venv/bin/python" "$DIR/manage.py" url)"
  exit 0
fi

echo
read -rp "نام کاربری پنل [admin]: " MB_USER; MB_USER=${MB_USER:-admin}
read -rsp "رمز عبور (خالی = تصادفی): " MB_PASS; echo
read -rp "پورت پنل [تصادفی]: " MB_PORT; MB_PORT=${MB_PORT:-$(shuf -i 20000-60000 -n 1)}
RND=$(head -c 6 /dev/urandom | od -An -tx1 | tr -d ' \n')
read -rp "مسیر مخفی URL [$RND]: " MB_BASE; MB_BASE=${MB_BASE:-$RND}
read -rp "دامنه برای SSL معتبر (خالی = گواهی خودامضا): " MB_DOMAIN
export MB_USER MB_PASS MB_PORT MB_BASE MB_DOMAIN

cd "$DIR"
"$DIR/venv/bin/python" "$DIR/manage.py" init | tee /tmp/mehrbod-init.txt

cat >/etc/systemd/system/mehrbod.service <<EOF
[Unit]
Description=Mehrbod AI Server Panel
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/venv/bin/python run.py
Restart=always
RestartSec=3
User=root

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable mehrbod >/dev/null 2>&1

if [ -n "$MB_DOMAIN" ]; then
  mehrbod ssl "$MB_DOMAIN" || { echo "صدور SSL ناموفق بود؛ گواهی خودامضا ساخته می‌شود."; mehrbod selfsign; }
else
  mehrbod selfsign
fi
systemctl restart mehrbod
sleep 2
rm -f /tmp/mehrbod-init.txt

echo
echo "================ نصب شد ================"
echo "آدرس پنل: $("$DIR/venv/bin/python" "$DIR/manage.py" url)"
echo "دستور مدیریت: mehrbod   (status | restart | logs | passwd | ssl | url | uninstall)"
echo "بعد از ورود، از «تنظیمات» کلید API جمنای را وارد کنید."
