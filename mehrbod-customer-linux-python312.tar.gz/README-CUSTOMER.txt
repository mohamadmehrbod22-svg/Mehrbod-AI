Mehrbod customer release

Install on a Linux VPS matching the Python minor version used for this build:
  sudo bash install.sh

This is a compiled Cython runtime, not cryptographic DRM. Build on the target OS/Python ABI.
The license server URL and public verification key are embedded in runtime/license_config.* at build time.
Never include the license server's private signing key in this package.
